package sample;

public class Seat {
}
